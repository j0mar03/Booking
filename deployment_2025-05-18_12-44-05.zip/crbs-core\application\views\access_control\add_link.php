
<p class="iconbar" id="access_control_add">
	<a href="<?= site_url('access_control/add/form?' . http_build_query($filter)) ?>" up-target="#access_control_add" up-history="false">
		<?= img("assets/images/ui/add.png", FALSE, "alt='Add entry' align='top' hspace='0' border='0'") ?>
		Add Entry
	</a>
</p>
