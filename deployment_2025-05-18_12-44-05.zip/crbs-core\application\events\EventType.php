<?php

final class EventType
{

	CONST USER_LOGGED_IN = 'user:logged_in';

}
