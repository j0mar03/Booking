<?php

$this->load->view('bookings_grid/table/slot/booked');
