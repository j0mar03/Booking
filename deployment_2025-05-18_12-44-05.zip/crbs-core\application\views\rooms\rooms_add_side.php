<dl>
  <dt>Room Information</dt>
  <dd>The only required information for a room is the <span>name</span> and <span>group</span> fields.</dd>
</dl>
