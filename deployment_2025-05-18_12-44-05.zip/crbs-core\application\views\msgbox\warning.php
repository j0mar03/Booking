<p class="msgbox exclamation"><?php echo $vars; ?></p>
