
<p>Use this page to specify the <?= anchor('schedules', 'Schedules') ?> that each <?= anchor('room_groups', 'Room Group') ?> will use within this session.</p>
<p>The chosen schedule for each group will apply to all rooms within it.</p>

<p>If you change the schedule for a room group, bookings against the previous schedule will no longer be accessible.</p>
<br>
