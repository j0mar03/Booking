<div class="bookings-create">
	<h4 style="margin: 0 32px 16px 0"><?= $title ?></h4>
	<?= $view ?>
</div>
