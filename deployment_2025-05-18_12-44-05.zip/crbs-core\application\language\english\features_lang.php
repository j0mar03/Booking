<?php

$lang['features_room_groups'] = 'Room Groups';
$lang['features_room_groups_description'] = 'Create different groups for different rooms and allow custom ordering.';
