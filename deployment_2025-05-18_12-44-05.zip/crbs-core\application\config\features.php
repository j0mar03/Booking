<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Experimental features that can be enabled in Settings.
 *
 */

$config['features'] = [
	// 'room_groups',
];
