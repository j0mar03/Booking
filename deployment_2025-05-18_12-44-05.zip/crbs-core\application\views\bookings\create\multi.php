<?php

// foreach ($selected_slots as $slot) {
// 	print_r(json_decode($slot));
// 	echo "<br>";
// }
