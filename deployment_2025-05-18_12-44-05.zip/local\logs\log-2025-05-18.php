<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-05-18 11:30:31 --> Config Class Initialized
INFO - 2025-05-18 11:30:31 --> Hooks Class Initialized
DEBUG - 2025-05-18 11:30:31 --> UTF-8 Support Enabled
INFO - 2025-05-18 11:30:31 --> Utf8 Class Initialized
INFO - 2025-05-18 11:30:31 --> URI Class Initialized
DEBUG - 2025-05-18 11:30:31 --> No URI present. Default controller set.
INFO - 2025-05-18 11:30:31 --> Router Class Initialized
INFO - 2025-05-18 11:30:31 --> Output Class Initialized
INFO - 2025-05-18 11:30:31 --> Security Class Initialized
DEBUG - 2025-05-18 11:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-18 11:30:31 --> Input Class Initialized
INFO - 2025-05-18 11:30:31 --> Language Class Initialized
INFO - 2025-05-18 11:30:31 --> Config Class Initialized
INFO - 2025-05-18 11:30:31 --> Loader Class Initialized
INFO - 2025-05-18 11:30:32 --> Helper loaded: url_helper
INFO - 2025-05-18 11:30:32 --> Helper loaded: form_helper
INFO - 2025-05-18 11:30:32 --> Helper loaded: date_helper
INFO - 2025-05-18 11:30:32 --> Helper loaded: cookie_helper
INFO - 2025-05-18 11:30:32 --> Helper loaded: directory_helper
INFO - 2025-05-18 11:30:32 --> Helper loaded: text_helper
INFO - 2025-05-18 11:30:32 --> Helper loaded: html_helper
INFO - 2025-05-18 11:30:32 --> Helper loaded: array_helper
INFO - 2025-05-18 11:30:32 --> Helper loaded: crbs_helper
INFO - 2025-05-18 11:30:32 --> Helper loaded: unpoly_helper
INFO - 2025-05-18 11:30:32 --> Model "Settings_model" initialized
INFO - 2025-05-18 11:30:32 --> Model "Menu_model" initialized
INFO - 2025-05-18 11:30:32 --> Controller Class Initialized
INFO - 2025-05-18 11:30:32 --> Helper loaded: file_helper
INFO - 2025-05-18 11:30:32 --> Config Class Initialized
INFO - 2025-05-18 11:30:32 --> Hooks Class Initialized
DEBUG - 2025-05-18 11:30:32 --> UTF-8 Support Enabled
INFO - 2025-05-18 11:30:32 --> Utf8 Class Initialized
INFO - 2025-05-18 11:30:32 --> URI Class Initialized
INFO - 2025-05-18 11:30:32 --> Router Class Initialized
INFO - 2025-05-18 11:30:32 --> Output Class Initialized
INFO - 2025-05-18 11:30:32 --> Security Class Initialized
DEBUG - 2025-05-18 11:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-18 11:30:32 --> Input Class Initialized
INFO - 2025-05-18 11:30:32 --> Language Class Initialized
INFO - 2025-05-18 11:30:32 --> Config Class Initialized
INFO - 2025-05-18 11:30:32 --> Loader Class Initialized
INFO - 2025-05-18 11:30:32 --> Helper loaded: url_helper
INFO - 2025-05-18 11:30:32 --> Helper loaded: form_helper
INFO - 2025-05-18 11:30:32 --> Helper loaded: date_helper
INFO - 2025-05-18 11:30:32 --> Helper loaded: cookie_helper
INFO - 2025-05-18 11:30:32 --> Helper loaded: directory_helper
INFO - 2025-05-18 11:30:32 --> Helper loaded: text_helper
INFO - 2025-05-18 11:30:32 --> Helper loaded: html_helper
INFO - 2025-05-18 11:30:32 --> Helper loaded: array_helper
INFO - 2025-05-18 11:30:32 --> Helper loaded: crbs_helper
INFO - 2025-05-18 11:30:32 --> Helper loaded: unpoly_helper
INFO - 2025-05-18 11:30:32 --> Model "Settings_model" initialized
INFO - 2025-05-18 11:30:32 --> Model "Menu_model" initialized
INFO - 2025-05-18 11:30:32 --> Controller Class Initialized
INFO - 2025-05-18 11:30:32 --> Helper loaded: file_helper
INFO - 2025-05-18 11:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-18 11:30:33 --> Form Validation Class Initialized
DEBUG - 2025-05-18 11:30:33 --> File loaded: C:\xampp\htdocs\classroom-booking\crbs-core\application\modules/install/libraries/Installer.php
INFO - 2025-05-18 11:30:33 --> Config Class Initialized
INFO - 2025-05-18 11:30:33 --> Hooks Class Initialized
DEBUG - 2025-05-18 11:30:33 --> UTF-8 Support Enabled
INFO - 2025-05-18 11:30:33 --> Utf8 Class Initialized
INFO - 2025-05-18 11:30:33 --> URI Class Initialized
INFO - 2025-05-18 11:30:33 --> Router Class Initialized
INFO - 2025-05-18 11:30:33 --> Output Class Initialized
INFO - 2025-05-18 11:30:33 --> Security Class Initialized
DEBUG - 2025-05-18 11:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-18 11:30:33 --> Input Class Initialized
INFO - 2025-05-18 11:30:33 --> Language Class Initialized
INFO - 2025-05-18 11:30:33 --> Config Class Initialized
INFO - 2025-05-18 11:30:33 --> Loader Class Initialized
INFO - 2025-05-18 11:30:33 --> Helper loaded: url_helper
INFO - 2025-05-18 11:30:33 --> Helper loaded: form_helper
INFO - 2025-05-18 11:30:33 --> Helper loaded: date_helper
INFO - 2025-05-18 11:30:33 --> Helper loaded: cookie_helper
INFO - 2025-05-18 11:30:33 --> Helper loaded: directory_helper
INFO - 2025-05-18 11:30:33 --> Helper loaded: text_helper
INFO - 2025-05-18 11:30:33 --> Helper loaded: html_helper
INFO - 2025-05-18 11:30:33 --> Helper loaded: array_helper
INFO - 2025-05-18 11:30:33 --> Helper loaded: crbs_helper
INFO - 2025-05-18 11:30:33 --> Helper loaded: unpoly_helper
INFO - 2025-05-18 11:30:33 --> Model "Settings_model" initialized
INFO - 2025-05-18 11:30:33 --> Model "Menu_model" initialized
INFO - 2025-05-18 11:30:33 --> Controller Class Initialized
INFO - 2025-05-18 11:30:33 --> Helper loaded: file_helper
INFO - 2025-05-18 11:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-18 11:30:33 --> Form Validation Class Initialized
DEBUG - 2025-05-18 11:30:33 --> File loaded: C:\xampp\htdocs\classroom-booking\crbs-core\application\modules/install/libraries/Installer.php
DEBUG - 2025-05-18 11:30:33 --> File loaded: C:\xampp\htdocs\classroom-booking\crbs-core\application\views\partials/submit.php
DEBUG - 2025-05-18 11:30:33 --> File loaded: C:\xampp\htdocs\classroom-booking\crbs-core\application\modules/install/views/config.php
DEBUG - 2025-05-18 11:30:33 --> File loaded: C:\xampp\htdocs\classroom-booking\crbs-core\application\modules/install/views/config_side.php
DEBUG - 2025-05-18 11:30:33 --> File loaded: C:\xampp\htdocs\classroom-booking\crbs-core\application\views\columns.php
DEBUG - 2025-05-18 11:30:33 --> File loaded: C:\xampp\htdocs\classroom-booking\crbs-core\application\views\layout.php
INFO - 2025-05-18 11:30:33 --> Final output sent to browser
DEBUG - 2025-05-18 11:30:33 --> Total execution time: 0.2633
INFO - 2025-05-18 11:34:02 --> Config Class Initialized
INFO - 2025-05-18 11:34:02 --> Hooks Class Initialized
DEBUG - 2025-05-18 11:34:02 --> UTF-8 Support Enabled
INFO - 2025-05-18 11:34:02 --> Utf8 Class Initialized
INFO - 2025-05-18 11:34:02 --> URI Class Initialized
INFO - 2025-05-18 11:34:02 --> Router Class Initialized
INFO - 2025-05-18 11:34:02 --> Output Class Initialized
INFO - 2025-05-18 11:34:02 --> Security Class Initialized
DEBUG - 2025-05-18 11:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-18 11:34:02 --> Input Class Initialized
INFO - 2025-05-18 11:34:02 --> Language Class Initialized
INFO - 2025-05-18 11:34:02 --> Config Class Initialized
INFO - 2025-05-18 11:34:02 --> Loader Class Initialized
INFO - 2025-05-18 11:34:02 --> Helper loaded: url_helper
INFO - 2025-05-18 11:34:02 --> Helper loaded: form_helper
INFO - 2025-05-18 11:34:02 --> Helper loaded: date_helper
INFO - 2025-05-18 11:34:02 --> Helper loaded: cookie_helper
INFO - 2025-05-18 11:34:02 --> Helper loaded: directory_helper
INFO - 2025-05-18 11:34:02 --> Helper loaded: text_helper
INFO - 2025-05-18 11:34:02 --> Helper loaded: html_helper
INFO - 2025-05-18 11:34:02 --> Helper loaded: array_helper
INFO - 2025-05-18 11:34:02 --> Helper loaded: crbs_helper
INFO - 2025-05-18 11:34:02 --> Helper loaded: unpoly_helper
INFO - 2025-05-18 11:34:02 --> Model "Settings_model" initialized
INFO - 2025-05-18 11:34:02 --> Model "Menu_model" initialized
INFO - 2025-05-18 11:34:02 --> Controller Class Initialized
INFO - 2025-05-18 11:34:02 --> Helper loaded: file_helper
INFO - 2025-05-18 11:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-18 11:34:03 --> Form Validation Class Initialized
DEBUG - 2025-05-18 11:34:03 --> File loaded: C:\xampp\htdocs\classroom-booking\crbs-core\application\modules/install/libraries/Installer.php
INFO - 2025-05-18 11:34:03 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2025-05-18 11:34:03 --> File loaded: C:\xampp\htdocs\classroom-booking\crbs-core\application\views\partials/submit.php
DEBUG - 2025-05-18 11:34:03 --> File loaded: C:\xampp\htdocs\classroom-booking\crbs-core\application\modules/install/views/config.php
DEBUG - 2025-05-18 11:34:03 --> File loaded: C:\xampp\htdocs\classroom-booking\crbs-core\application\modules/install/views/config_side.php
DEBUG - 2025-05-18 11:34:03 --> File loaded: C:\xampp\htdocs\classroom-booking\crbs-core\application\views\columns.php
DEBUG - 2025-05-18 11:34:03 --> File loaded: C:\xampp\htdocs\classroom-booking\crbs-core\application\views\layout.php
INFO - 2025-05-18 11:34:03 --> Final output sent to browser
DEBUG - 2025-05-18 11:34:03 --> Total execution time: 0.2052
INFO - 2025-05-18 11:43:40 --> Config Class Initialized
INFO - 2025-05-18 11:43:40 --> Hooks Class Initialized
DEBUG - 2025-05-18 11:43:40 --> UTF-8 Support Enabled
INFO - 2025-05-18 11:43:40 --> Utf8 Class Initialized
INFO - 2025-05-18 11:43:40 --> URI Class Initialized
INFO - 2025-05-18 11:43:40 --> Router Class Initialized
INFO - 2025-05-18 11:43:40 --> Output Class Initialized
INFO - 2025-05-18 11:43:40 --> Security Class Initialized
DEBUG - 2025-05-18 11:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-18 11:43:40 --> Input Class Initialized
INFO - 2025-05-18 11:43:40 --> Language Class Initialized
INFO - 2025-05-18 11:43:40 --> Config Class Initialized
INFO - 2025-05-18 11:43:40 --> Loader Class Initialized
INFO - 2025-05-18 11:43:40 --> Helper loaded: url_helper
INFO - 2025-05-18 11:43:40 --> Helper loaded: form_helper
INFO - 2025-05-18 11:43:40 --> Helper loaded: date_helper
INFO - 2025-05-18 11:43:40 --> Helper loaded: cookie_helper
INFO - 2025-05-18 11:43:40 --> Helper loaded: directory_helper
INFO - 2025-05-18 11:43:40 --> Helper loaded: text_helper
INFO - 2025-05-18 11:43:40 --> Helper loaded: html_helper
INFO - 2025-05-18 11:43:40 --> Helper loaded: array_helper
INFO - 2025-05-18 11:43:40 --> Helper loaded: crbs_helper
INFO - 2025-05-18 11:43:40 --> Helper loaded: unpoly_helper
INFO - 2025-05-18 11:43:40 --> Model "Settings_model" initialized
INFO - 2025-05-18 11:43:40 --> Model "Menu_model" initialized
INFO - 2025-05-18 11:43:40 --> Controller Class Initialized
INFO - 2025-05-18 11:43:40 --> Helper loaded: file_helper
INFO - 2025-05-18 11:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-18 11:43:40 --> Form Validation Class Initialized
DEBUG - 2025-05-18 11:43:40 --> File loaded: C:\xampp\htdocs\classroom-booking\crbs-core\application\modules/install/libraries/Installer.php
DEBUG - 2025-05-18 11:43:40 --> File loaded: C:\xampp\htdocs\classroom-booking\crbs-core\application\views\partials/submit.php
DEBUG - 2025-05-18 11:43:40 --> File loaded: C:\xampp\htdocs\classroom-booking\crbs-core\application\modules/install/views/config.php
DEBUG - 2025-05-18 11:43:40 --> File loaded: C:\xampp\htdocs\classroom-booking\crbs-core\application\modules/install/views/config_side.php
DEBUG - 2025-05-18 11:43:40 --> File loaded: C:\xampp\htdocs\classroom-booking\crbs-core\application\views\columns.php
DEBUG - 2025-05-18 11:43:40 --> File loaded: C:\xampp\htdocs\classroom-booking\crbs-core\application\views\layout.php
INFO - 2025-05-18 11:43:40 --> Final output sent to browser
DEBUG - 2025-05-18 11:43:40 --> Total execution time: 0.2316
INFO - 2025-05-18 11:44:09 --> Config Class Initialized
INFO - 2025-05-18 11:44:09 --> Hooks Class Initialized
DEBUG - 2025-05-18 11:44:09 --> UTF-8 Support Enabled
INFO - 2025-05-18 11:44:09 --> Utf8 Class Initialized
INFO - 2025-05-18 11:44:09 --> URI Class Initialized
INFO - 2025-05-18 11:44:09 --> Router Class Initialized
INFO - 2025-05-18 11:44:09 --> Output Class Initialized
INFO - 2025-05-18 11:44:09 --> Security Class Initialized
DEBUG - 2025-05-18 11:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-18 11:44:09 --> Input Class Initialized
INFO - 2025-05-18 11:44:09 --> Language Class Initialized
INFO - 2025-05-18 11:44:10 --> Config Class Initialized
INFO - 2025-05-18 11:44:10 --> Loader Class Initialized
INFO - 2025-05-18 11:44:10 --> Helper loaded: url_helper
INFO - 2025-05-18 11:44:10 --> Helper loaded: form_helper
INFO - 2025-05-18 11:44:10 --> Helper loaded: date_helper
INFO - 2025-05-18 11:44:10 --> Helper loaded: cookie_helper
INFO - 2025-05-18 11:44:10 --> Helper loaded: directory_helper
INFO - 2025-05-18 11:44:10 --> Helper loaded: text_helper
INFO - 2025-05-18 11:44:10 --> Helper loaded: html_helper
INFO - 2025-05-18 11:44:10 --> Helper loaded: array_helper
INFO - 2025-05-18 11:44:10 --> Helper loaded: crbs_helper
INFO - 2025-05-18 11:44:10 --> Helper loaded: unpoly_helper
INFO - 2025-05-18 11:44:10 --> Model "Settings_model" initialized
INFO - 2025-05-18 11:44:10 --> Model "Menu_model" initialized
INFO - 2025-05-18 11:44:10 --> Controller Class Initialized
INFO - 2025-05-18 11:44:10 --> Helper loaded: file_helper
INFO - 2025-05-18 11:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-18 11:44:10 --> Form Validation Class Initialized
DEBUG - 2025-05-18 11:44:10 --> File loaded: C:\xampp\htdocs\classroom-booking\crbs-core\application\modules/install/libraries/Installer.php
INFO - 2025-05-18 11:44:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-18 11:44:10 --> Database Driver Class Initialized
ERROR - 2025-05-18 11:44:10 --> Severity: Warning --> Undefined variable $err C:\xampp\htdocs\classroom-booking\crbs-core\application\modules\install\controllers\Install.php 172
INFO - 2025-05-18 11:44:10 --> Config Class Initialized
INFO - 2025-05-18 11:44:10 --> Hooks Class Initialized
DEBUG - 2025-05-18 11:44:10 --> UTF-8 Support Enabled
INFO - 2025-05-18 11:44:10 --> Utf8 Class Initialized
INFO - 2025-05-18 11:44:10 --> URI Class Initialized
INFO - 2025-05-18 11:44:10 --> Router Class Initialized
INFO - 2025-05-18 11:44:10 --> Output Class Initialized
INFO - 2025-05-18 11:44:10 --> Security Class Initialized
DEBUG - 2025-05-18 11:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-18 11:44:10 --> Input Class Initialized
INFO - 2025-05-18 11:44:10 --> Language Class Initialized
INFO - 2025-05-18 11:44:10 --> Config Class Initialized
INFO - 2025-05-18 11:44:10 --> Loader Class Initialized
INFO - 2025-05-18 11:44:10 --> Helper loaded: url_helper
INFO - 2025-05-18 11:44:10 --> Helper loaded: form_helper
INFO - 2025-05-18 11:44:10 --> Helper loaded: date_helper
INFO - 2025-05-18 11:44:10 --> Helper loaded: cookie_helper
INFO - 2025-05-18 11:44:10 --> Helper loaded: directory_helper
INFO - 2025-05-18 11:44:10 --> Helper loaded: text_helper
INFO - 2025-05-18 11:44:10 --> Helper loaded: html_helper
INFO - 2025-05-18 11:44:10 --> Helper loaded: array_helper
INFO - 2025-05-18 11:44:10 --> Helper loaded: crbs_helper
INFO - 2025-05-18 11:44:10 --> Helper loaded: unpoly_helper
INFO - 2025-05-18 11:44:10 --> Model "Settings_model" initialized
INFO - 2025-05-18 11:44:10 --> Model "Menu_model" initialized
INFO - 2025-05-18 11:44:10 --> Controller Class Initialized
INFO - 2025-05-18 11:44:10 --> Helper loaded: file_helper
INFO - 2025-05-18 11:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-18 11:44:10 --> Form Validation Class Initialized
DEBUG - 2025-05-18 11:44:10 --> File loaded: C:\xampp\htdocs\classroom-booking\crbs-core\application\modules/install/libraries/Installer.php
DEBUG - 2025-05-18 11:44:10 --> File loaded: C:\xampp\htdocs\classroom-booking\crbs-core\application\views\partials/submit.php
DEBUG - 2025-05-18 11:44:10 --> File loaded: C:\xampp\htdocs\classroom-booking\crbs-core\application\modules/install/views/info.php
DEBUG - 2025-05-18 11:44:10 --> File loaded: C:\xampp\htdocs\classroom-booking\crbs-core\application\modules/install/views/info_side.php
DEBUG - 2025-05-18 11:44:10 --> File loaded: C:\xampp\htdocs\classroom-booking\crbs-core\application\views\columns.php
DEBUG - 2025-05-18 11:44:10 --> File loaded: C:\xampp\htdocs\classroom-booking\crbs-core\application\views\layout.php
INFO - 2025-05-18 11:44:10 --> Final output sent to browser
DEBUG - 2025-05-18 11:44:10 --> Total execution time: 0.2218
INFO - 2025-05-18 11:44:40 --> Config Class Initialized
INFO - 2025-05-18 11:44:40 --> Hooks Class Initialized
DEBUG - 2025-05-18 11:44:40 --> UTF-8 Support Enabled
INFO - 2025-05-18 11:44:40 --> Utf8 Class Initialized
INFO - 2025-05-18 11:44:40 --> URI Class Initialized
INFO - 2025-05-18 11:44:40 --> Router Class Initialized
INFO - 2025-05-18 11:44:40 --> Output Class Initialized
INFO - 2025-05-18 11:44:40 --> Security Class Initialized
DEBUG - 2025-05-18 11:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-18 11:44:40 --> Input Class Initialized
INFO - 2025-05-18 11:44:40 --> Language Class Initialized
INFO - 2025-05-18 11:44:40 --> Config Class Initialized
INFO - 2025-05-18 11:44:40 --> Loader Class Initialized
INFO - 2025-05-18 11:44:40 --> Helper loaded: url_helper
INFO - 2025-05-18 11:44:40 --> Helper loaded: form_helper
INFO - 2025-05-18 11:44:40 --> Helper loaded: date_helper
INFO - 2025-05-18 11:44:40 --> Helper loaded: cookie_helper
INFO - 2025-05-18 11:44:40 --> Helper loaded: directory_helper
INFO - 2025-05-18 11:44:40 --> Helper loaded: text_helper
INFO - 2025-05-18 11:44:40 --> Helper loaded: html_helper
INFO - 2025-05-18 11:44:40 --> Helper loaded: array_helper
INFO - 2025-05-18 11:44:40 --> Helper loaded: crbs_helper
INFO - 2025-05-18 11:44:40 --> Helper loaded: unpoly_helper
INFO - 2025-05-18 11:44:40 --> Model "Settings_model" initialized
INFO - 2025-05-18 11:44:40 --> Model "Menu_model" initialized
INFO - 2025-05-18 11:44:40 --> Controller Class Initialized
INFO - 2025-05-18 11:44:40 --> Helper loaded: file_helper
INFO - 2025-05-18 11:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-18 11:44:40 --> Form Validation Class Initialized
DEBUG - 2025-05-18 11:44:40 --> File loaded: C:\xampp\htdocs\classroom-booking\crbs-core\application\modules/install/libraries/Installer.php
INFO - 2025-05-18 11:44:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-18 11:44:40 --> Config Class Initialized
INFO - 2025-05-18 11:44:40 --> Hooks Class Initialized
DEBUG - 2025-05-18 11:44:40 --> UTF-8 Support Enabled
INFO - 2025-05-18 11:44:40 --> Utf8 Class Initialized
INFO - 2025-05-18 11:44:40 --> URI Class Initialized
INFO - 2025-05-18 11:44:40 --> Router Class Initialized
INFO - 2025-05-18 11:44:40 --> Output Class Initialized
INFO - 2025-05-18 11:44:40 --> Security Class Initialized
DEBUG - 2025-05-18 11:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-18 11:44:40 --> Input Class Initialized
INFO - 2025-05-18 11:44:40 --> Language Class Initialized
INFO - 2025-05-18 11:44:40 --> Config Class Initialized
INFO - 2025-05-18 11:44:40 --> Loader Class Initialized
INFO - 2025-05-18 11:44:40 --> Helper loaded: url_helper
INFO - 2025-05-18 11:44:40 --> Helper loaded: form_helper
INFO - 2025-05-18 11:44:40 --> Helper loaded: date_helper
INFO - 2025-05-18 11:44:40 --> Helper loaded: cookie_helper
INFO - 2025-05-18 11:44:40 --> Helper loaded: directory_helper
INFO - 2025-05-18 11:44:40 --> Helper loaded: text_helper
INFO - 2025-05-18 11:44:40 --> Helper loaded: html_helper
INFO - 2025-05-18 11:44:40 --> Helper loaded: array_helper
INFO - 2025-05-18 11:44:40 --> Helper loaded: crbs_helper
INFO - 2025-05-18 11:44:40 --> Helper loaded: unpoly_helper
INFO - 2025-05-18 11:44:40 --> Model "Settings_model" initialized
INFO - 2025-05-18 11:44:40 --> Model "Menu_model" initialized
INFO - 2025-05-18 11:44:40 --> Controller Class Initialized
INFO - 2025-05-18 11:44:40 --> Helper loaded: file_helper
INFO - 2025-05-18 11:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-18 11:44:40 --> Form Validation Class Initialized
DEBUG - 2025-05-18 11:44:40 --> File loaded: C:\xampp\htdocs\classroom-booking\crbs-core\application\modules/install/libraries/Installer.php
INFO - 2025-05-18 11:44:40 --> Database Driver Class Initialized
DEBUG - 2025-05-18 11:44:40 --> File loaded: C:\xampp\htdocs\classroom-booking\crbs-core\application\views\partials/submit.php
DEBUG - 2025-05-18 11:44:40 --> File loaded: C:\xampp\htdocs\classroom-booking\crbs-core\application\modules/install/views/check.php
DEBUG - 2025-05-18 11:44:40 --> File loaded: C:\xampp\htdocs\classroom-booking\crbs-core\application\views\layout.php
INFO - 2025-05-18 11:44:40 --> Final output sent to browser
DEBUG - 2025-05-18 11:44:40 --> Total execution time: 0.2744
INFO - 2025-05-18 11:46:59 --> Config Class Initialized
INFO - 2025-05-18 11:46:59 --> Hooks Class Initialized
DEBUG - 2025-05-18 11:46:59 --> UTF-8 Support Enabled
INFO - 2025-05-18 11:46:59 --> Utf8 Class Initialized
INFO - 2025-05-18 11:46:59 --> URI Class Initialized
INFO - 2025-05-18 11:46:59 --> Router Class Initialized
INFO - 2025-05-18 11:46:59 --> Output Class Initialized
INFO - 2025-05-18 11:46:59 --> Security Class Initialized
DEBUG - 2025-05-18 11:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-18 11:46:59 --> Input Class Initialized
INFO - 2025-05-18 11:46:59 --> Language Class Initialized
INFO - 2025-05-18 11:46:59 --> Config Class Initialized
INFO - 2025-05-18 11:46:59 --> Loader Class Initialized
INFO - 2025-05-18 11:46:59 --> Helper loaded: url_helper
INFO - 2025-05-18 11:46:59 --> Helper loaded: form_helper
INFO - 2025-05-18 11:46:59 --> Helper loaded: date_helper
INFO - 2025-05-18 11:46:59 --> Helper loaded: cookie_helper
INFO - 2025-05-18 11:46:59 --> Helper loaded: directory_helper
INFO - 2025-05-18 11:46:59 --> Helper loaded: text_helper
INFO - 2025-05-18 11:46:59 --> Helper loaded: html_helper
INFO - 2025-05-18 11:46:59 --> Helper loaded: array_helper
INFO - 2025-05-18 11:46:59 --> Helper loaded: crbs_helper
INFO - 2025-05-18 11:46:59 --> Helper loaded: unpoly_helper
INFO - 2025-05-18 11:46:59 --> Model "Settings_model" initialized
INFO - 2025-05-18 11:46:59 --> Model "Menu_model" initialized
INFO - 2025-05-18 11:46:59 --> Controller Class Initialized
INFO - 2025-05-18 11:46:59 --> Helper loaded: file_helper
INFO - 2025-05-18 11:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-18 11:46:59 --> Form Validation Class Initialized
DEBUG - 2025-05-18 11:46:59 --> File loaded: C:\xampp\htdocs\classroom-booking\crbs-core\application\modules/install/libraries/Installer.php
INFO - 2025-05-18 11:46:59 --> Database Driver Class Initialized
DEBUG - 2025-05-18 11:46:59 --> File loaded: C:\xampp\htdocs\classroom-booking\crbs-core\application\views\partials/submit.php
DEBUG - 2025-05-18 11:46:59 --> File loaded: C:\xampp\htdocs\classroom-booking\crbs-core\application\modules/install/views/check.php
DEBUG - 2025-05-18 11:46:59 --> File loaded: C:\xampp\htdocs\classroom-booking\crbs-core\application\views\layout.php
INFO - 2025-05-18 11:46:59 --> Final output sent to browser
DEBUG - 2025-05-18 11:46:59 --> Total execution time: 0.1411
INFO - 2025-05-18 11:47:03 --> Config Class Initialized
INFO - 2025-05-18 11:47:03 --> Hooks Class Initialized
DEBUG - 2025-05-18 11:47:03 --> UTF-8 Support Enabled
INFO - 2025-05-18 11:47:03 --> Utf8 Class Initialized
INFO - 2025-05-18 11:47:03 --> URI Class Initialized
INFO - 2025-05-18 11:47:03 --> Router Class Initialized
INFO - 2025-05-18 11:47:03 --> Output Class Initialized
INFO - 2025-05-18 11:47:03 --> Security Class Initialized
DEBUG - 2025-05-18 11:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-18 11:47:03 --> Input Class Initialized
INFO - 2025-05-18 11:47:03 --> Language Class Initialized
INFO - 2025-05-18 11:47:03 --> Config Class Initialized
INFO - 2025-05-18 11:47:03 --> Loader Class Initialized
INFO - 2025-05-18 11:47:03 --> Helper loaded: url_helper
INFO - 2025-05-18 11:47:03 --> Helper loaded: form_helper
INFO - 2025-05-18 11:47:03 --> Helper loaded: date_helper
INFO - 2025-05-18 11:47:03 --> Helper loaded: cookie_helper
INFO - 2025-05-18 11:47:03 --> Helper loaded: directory_helper
INFO - 2025-05-18 11:47:03 --> Helper loaded: text_helper
INFO - 2025-05-18 11:47:03 --> Helper loaded: html_helper
INFO - 2025-05-18 11:47:03 --> Helper loaded: array_helper
INFO - 2025-05-18 11:47:03 --> Helper loaded: crbs_helper
INFO - 2025-05-18 11:47:03 --> Helper loaded: unpoly_helper
INFO - 2025-05-18 11:47:03 --> Model "Settings_model" initialized
INFO - 2025-05-18 11:47:03 --> Model "Menu_model" initialized
INFO - 2025-05-18 11:47:03 --> Controller Class Initialized
INFO - 2025-05-18 11:47:03 --> Helper loaded: file_helper
INFO - 2025-05-18 11:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-18 11:47:03 --> Form Validation Class Initialized
DEBUG - 2025-05-18 11:47:03 --> File loaded: C:\xampp\htdocs\classroom-booking\crbs-core\application\modules/install/libraries/Installer.php
INFO - 2025-05-18 11:47:03 --> Database Driver Class Initialized
INFO - 2025-05-18 11:47:03 --> Database Driver Class Initialized
INFO - 2025-05-18 11:47:04 --> Migrations Class Initialized
INFO - 2025-05-18 11:47:04 --> Language file loaded: language/english/migration_lang.php
INFO - 2025-05-18 11:47:04 --> Database Forge Class Initialized
DEBUG - 2025-05-18 11:47:04 --> Migrating up from version 20210901111800 to version 20220709093800
DEBUG - 2025-05-18 11:47:04 --> Migrating up from version 20220709093800 to version 20220929222700
DEBUG - 2025-05-18 11:47:04 --> Migrating up from version 20220929222700 to version 20230120160200
DEBUG - 2025-05-18 11:47:04 --> Migrating up from version 20230120160200 to version 20230120182100
DEBUG - 2025-05-18 11:47:04 --> Migrating up from version 20230120182100 to version 20230121141000
DEBUG - 2025-05-18 11:47:04 --> Migrating up from version 20230121141000 to version 20230210105700
DEBUG - 2025-05-18 11:47:04 --> Migrating up from version 20230210105700 to version 20230404104100
DEBUG - 2025-05-18 11:47:04 --> Migrating up from version 20230404104100 to version 20230404104200
DEBUG - 2025-05-18 11:47:04 --> Migrating up from version 20230404104200 to version 20230404104300
DEBUG - 2025-05-18 11:47:04 --> Migrating up from version 20230404104300 to version 20230428161900
DEBUG - 2025-05-18 11:47:05 --> Migrating up from version 20230428161900 to version 20230428163200
DEBUG - 2025-05-18 11:47:05 --> Migrating up from version 20230428163200 to version 20230428183600
DEBUG - 2025-05-18 11:47:05 --> Migrating up from version 20230428183600 to version 20230428185900
DEBUG - 2025-05-18 11:47:05 --> Migrating up from version 20230428185900 to version 20230916122200
DEBUG - 2025-05-18 11:47:05 --> Finished migrating to 20230916122200
INFO - 2025-05-18 11:47:05 --> Parser Class Initialized
