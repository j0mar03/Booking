<?php

$lang['auth_ldap_no_server_or_port'] = 'No server and/or port supplied.';
$lang['auth_ldap_no_socket_connection'] = 'Connection error or timed out.';
$lang['auth_ldap_invalid_ldap_uri'] = 'Invalid LDAP connection URI.';
$lang['auth_ldap_no_username_or_password'] = 'No username and/or password.';
$lang['auth_ldap_bind_error'] = 'LDAP bind error or bad username and/or password.';
$lang['auth_ldap_search_error'] = 'LDAP search error.';
$lang['auth_ldap_search_num_results_error'] = 'LDAP search did not return exactly one result.';
$lang['auth_ldap_search_get_entry_error'] = 'LDAP get search result entry error.';
$lang['auth_ldap_search_get_attributes_error'] = 'LDAP get user attributes error.';
