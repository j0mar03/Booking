<?php
defined('BASEPATH') OR exit('No direct script access allowed');

return array(

	'config' => array(
		'base_url' => 'http://localhost/classroom-booking/',
		'log_threshold' => 1,
		'index_page' => 'index.php',
		'uri_protocol' => 'REQUEST_URI',
	),

	'database' => array(
		'hostname' => 'localhost',
		'port' => '3306',
		'username' => 'root',
		'password' => 'it3ch',
		'database' => 'if0_39013535_csbook',
		'dbdriver' => 'mysqli',
	),

);
